import React from 'react';
import './App.css';
import Header2 from './components/common/Header';
function App() {
  return (
    <div className="App">
      <Header2 />
   <p>Hello, React.</p>
    </div>
  );
}

export default App;
