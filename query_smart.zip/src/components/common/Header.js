import React from 'react';
//import '../../src/styles/header';
import './header1.css';

// src\styles\header.scss
//src/styles/header.scss
function Header(){
    return(<div> 
   <header class="header">
  <div class="header__logo logo">Logo</div>
  <ul class="header__nav nav">
    <li class="header__nav-item nav-item"><a href="#" class="header__nav-link nav-link">Home</a></li>
    <li class="header__nav-item nav-item"><a href="#" class="header__nav-link nav-link">About</a></li>
    <li class="header__nav-item nav-item"><a href="#" class="header__nav-link nav-link">Contact</a></li>
  </ul>
</header>

    </div>);
}
export default Header;